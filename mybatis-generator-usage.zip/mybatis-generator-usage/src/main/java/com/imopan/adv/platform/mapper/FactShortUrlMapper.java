package com.imopan.adv.platform.mapper;

import com.imopan.adv.common.mapper.BaseMapper;
import com.imopan.adv.platform.entity.FactShortUrl;
import com.imopan.adv.platform.entity.example.FactShortUrlExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface FactShortUrlMapper extends BaseMapper<Integer, FactShortUrl, FactShortUrlExample> {
}