package com.imopan.adv.platform.entity;

import com.imopan.adv.common.entity.PersistentObject;
import java.util.Date;

public class FactShortUrl extends PersistentObject {
    private Integer id;

    private String orignalUrl;

    private String shortUrl;

    private Date createTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOrignalUrl() {
        return orignalUrl;
    }

    public void setOrignalUrl(String orignalUrl) {
        this.orignalUrl = orignalUrl == null ? null : orignalUrl.trim();
    }

    public String getShortUrl() {
        return shortUrl;
    }

    public void setShortUrl(String shortUrl) {
        this.shortUrl = shortUrl == null ? null : shortUrl.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        FactShortUrl other = (FactShortUrl) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getOrignalUrl() == null ? other.getOrignalUrl() == null : this.getOrignalUrl().equals(other.getOrignalUrl()))
            && (this.getShortUrl() == null ? other.getShortUrl() == null : this.getShortUrl().equals(other.getShortUrl()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getOrignalUrl() == null) ? 0 : getOrignalUrl().hashCode());
        result = prime * result + ((getShortUrl() == null) ? 0 : getShortUrl().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        return result;
    }
}