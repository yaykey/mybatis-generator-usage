package com.imopan.adv.platform.business.impl;

import com.imopan.adv.common.business.BaseManager;
import com.imopan.adv.common.mapper.BaseMapper;
import com.imopan.adv.platform.entity.FactShortUrl;
import com.imopan.adv.platform.entity.example.FactShortUrlExample;
import com.imopan.adv.platform.mapper.FactShortUrlMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("factShortUrlManager")
public class FactShortUrlManager extends BaseManager<Integer, FactShortUrl, FactShortUrlExample> {
    @Autowired
    private FactShortUrlMapper factShortUrlMapper;

    @Override
    public BaseMapper<Integer, FactShortUrl, FactShortUrlExample> getMapper() {
        return factShortUrlMapper;
    }
}